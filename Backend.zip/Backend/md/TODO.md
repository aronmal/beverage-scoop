# TODO
- properly add md files!
- finish Readme
- research!