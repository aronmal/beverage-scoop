# Links
- https://tutorials-raspberrypi.com/how-to-arduino-raspberry-pi-communication/
